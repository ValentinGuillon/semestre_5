(*

Réalisez les fonction suivantes :

    Une fonction qui a un flottant x associe son cube ;
    Une fonction qui prend trois flottants en arguments : a, b et epsilon, et qui dit si a est égal à b à epsilon prêt. Pour se simplifier la tâche, on considère que a sera toujours plus grand que b ;
    Une fonction qui prend un caractère et un entier, et qui dit si cette entier est le code ASCII du caractère ou non. Vous pouvez tester avec 'A' qui a 65 comme code ASCII.
*)


let float_cube x = x *. x *. x;;





