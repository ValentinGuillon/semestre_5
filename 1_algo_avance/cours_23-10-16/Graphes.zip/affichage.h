
/* Affichage du tableau des accessibles */
void print_acc(int *tab, int taille, int s);

/* Affichage du tableau des distances */
void print_dist(int *tab, int taille, int s);

